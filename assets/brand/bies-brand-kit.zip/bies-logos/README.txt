BUILD IN EL SALVADOR — BRAND KIT
buildinelsalvador.com


  Logos/                                    16 PNG logos, transparent, ~1080px
  Build in El Salvador — Brand Guidelines.pdf   the full guidelines


THE LOGOS

Four marks, each in three versions:

  horizontal   the full lockup — the default choice
  vertical     the lockup stacked, for narrow or square spaces
  Badge        the round seal
  Icon         the mark alone, no wordmark
  favicon      the mark cropped tight, for browser tabs and app icons

  ...light background   for use on white or light colors
  ...dark background    for use on navy or dark colors
  ...white              all-white, for photos and busy backgrounds

The guidelines PDF covers clear space, minimum sizes, which mark to use
where, the full color scales and our typography. Read it before you place
the logo somewhere permanent.


USING THE LOGO AS A PARTNER

Please do:
  - Use it to show you're a Build in El Salvador partner, sponsor or member.
  - Follow the clear space and minimum sizes in the guidelines.
  - Pick the version that contrasts with your background.

Please don't:
  - Stretch, rotate, recolor or add effects to it.
  - Rebuild the lockup, change the typeface, or crop the mark.
  - Use it in a way that suggests we endorse a product or company we haven't.

The logo and the Build in El Salvador name are ours. We're glad to see them
used by the people we actually work with.


ANYTHING ELSE

Need a vector for print or large-format signage, a co-branded lockup, or a
format that isn't here? Write to info@buildinelsalvador.com.

Our display typeface, PP Formula Narrow, is licensed to us and isn't ours to
pass on, so it isn't in this kit. Body copy is Inter, which is free from
Google Fonts.
