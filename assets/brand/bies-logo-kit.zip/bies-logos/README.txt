BUILD IN EL SALVADOR — LOGO KIT
buildinelsalvador.com


WHAT'S IN HERE

16 PNG logos, about 1080px on their longest side, with transparent
backgrounds. Four marks, each in three versions:

  horizontal   the full lockup — the default choice
  vertical     the lockup stacked, for narrow or square spaces
  Badge        the round seal
  Icon         the mark alone, no wordmark
  favicon      the mark cropped tight, for browser tabs and app icons

  ...light background   for use on white or light colors
  ...dark background    for use on navy or dark colors
  ...white              all-white, for photos and busy backgrounds


BRAND COLORS

  Deep Navy      #121E5A
  Cobalt Blue    #0047AB
  Blaze Orange   #FF5B00
  Snow           #F9F5F4


USING THE LOGO

Please do:
  - Use it to show you're a Build in El Salvador partner, sponsor or member.
  - Leave clear space around it — at least the height of the "B".
  - Pick the version that contrasts with your background.

Please don't:
  - Stretch, rotate, recolor or add effects to it.
  - Rebuild the lockup, change the typeface, or crop the mark.
  - Place it on a background that makes it hard to read.
  - Use it in a way that suggests we endorse a product or company we haven't.

The logo and name are the property of Build in El Salvador.

Need a vector (SVG or EPS) for print or large-format signage, or a format
that isn't here? Write to info@buildinelsalvador.com and we'll send it over.

The brand typeface (PP Formula Narrow) is licensed and is not included in this kit.
